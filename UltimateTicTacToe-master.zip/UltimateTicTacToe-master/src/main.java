public class main {
    public static void main(String [] args)
    {
        GuiUTTT guiUTTT=new GuiUTTT();
        GuiSelection g=new GuiSelection(guiUTTT);
    }
}
